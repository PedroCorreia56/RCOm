#ifndef ALARME_H
#define ALARME_H

void atende();
void setupAlarm(int newMaxTries, int newTimeout);

#endif