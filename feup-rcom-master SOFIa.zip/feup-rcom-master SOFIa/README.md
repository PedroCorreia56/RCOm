# feup-rcom
Projects for the Computer Networks (RCOM) class of the Master in Informatics and Computer Engineering (MIEIC) at the Faculty of Engineering of the University of Porto (FEUP).
<br><br>
Made in colaboration with [Julieta Frade](https://github.com/julietafrade97) and [Catarina Ferreira](https://github.com/LivingCat).<br>
**Completed in 22/12/2017.**

## First Project
Transfering files between computers with a serial port.

## Second Project
Configuring a computer network in the lab, development of a ftp protocol based download application.
